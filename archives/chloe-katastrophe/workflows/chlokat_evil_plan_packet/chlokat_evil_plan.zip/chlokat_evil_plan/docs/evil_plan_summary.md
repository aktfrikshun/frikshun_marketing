# ChloKat / FrikShun Evil Plan Summary

## Brand Architecture

- FrikShun is the umbrella creative/engineering identity.
- Chloe Katastrophe is the virtual artist and fictional character.
- ChloKat is Chloe Katastrophe's nickname.
- Public home: `chlokat.frikshun.com`.

The site should feel like a FrikShun research archive where Chloe's memories, songs, images, videos, and transmissions are being reconstructed.

## Core Product Concept

Build a creator operating system for fictional/virtual artists.

Chloe is the first resident.

The system should:

1. Store artifacts.
2. Preserve canon.
3. Generate platform-native social drafts.
4. Publish or assist publishing to social platforms.
5. Create public archive pages.
6. Let fans search the archive.
7. Let fans talk to Chloe through approved canon.
8. Track which content creates engagement and superfans.

## Platform Strategy

### Primary Content Platforms

- Facebook Page
- Instagram
- YouTube
- TikTok
- X / Twitter
- FanVue
- ChloKat Archive

### Music Distribution

Managed by DistroKid:

- Apple Music
- Spotify
- YouTube Music
- Amazon Music
- Deezer
- Tidal
- etc.

ChloKat stores release metadata and outgoing links only.

### Phase 2 Community Platforms

- Reddit
- Discord
- Bluesky
- Threads

Reddit should not be treated as a simple broadcast publisher. It should be introduced as a community intelligence and conversation workflow.

## Guiding Principle

Do not make Allen handcraft seven separate posts every time he creates content.

The system should turn one artifact into platform-appropriate drafts, each written for the native audience and purpose of that platform.

## First Useful Version

One upload. Seven drafts. Five minutes.

